export default function getRequestAnimationFrame(): any;
export declare function cancelRequestAnimationFrame(id: any): any;
