import ko_KR from '../../date-picker/locale/ko_KR';
export default ko_KR;
