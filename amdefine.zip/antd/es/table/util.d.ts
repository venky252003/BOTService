export declare function flatArray(data?: Object[], childrenName?: string): Object[];
export declare function treeMap(tree: Object[], mapper: Function, childrenName?: string): any[];
export declare function flatFilter(tree: any[], callback: Function): any;
export declare function normalizeColumns(elements: any): any[];
