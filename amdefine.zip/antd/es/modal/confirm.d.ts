export default function confirm(config: any): {
    destroy: (...args: any[]) => void;
};
