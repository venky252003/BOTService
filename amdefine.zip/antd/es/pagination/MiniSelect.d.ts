/// <reference types="react" />
import React from 'react';
import { OptionProps } from '../select';
export default class MiniSelect extends React.Component<any, any> {
    static Option: React.ClassicComponentClass<OptionProps>;
    render(): JSX.Element;
}
